
var firstName = prompt('Hello! What is your first name?');

var lastName = prompt('Okay. What is your last name?');

var favColor = prompt('Cool. What is your favorite color?');

alert('Your name is ' + firstName + ' ' + lastName + ' and your favorite color is ' + favColor);